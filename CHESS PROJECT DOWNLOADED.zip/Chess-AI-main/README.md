# Chess-AI
A fairly simple chess program, implementing in C# in the Unity game engine.
 
[Watch video](https://www.youtube.com/watch?v=U4ogK0MIzqk)

[Download and play](https://sebastian.itch.io/chess-ai)
![Image](https://github.com/SebLague/Images/blob/master/Chess.png)
